$(function() {
  $("#cover1").on("mouseover", function() {
    $("#cover1").animate({ opacity: 0.6 });
    $("#foft").animate({ opacity: 0 });
    $("#cover1t").animate({ opacity: 1 });
  });

  $("#cover1").on("mouseout", function() {
    $("#cover1").animate({ opacity: 0 });
    $("#foft").animate({ opacity: 1 });
    $("#cover1t").animate({ opacity: 0 });
  });

  $("#cover1t").on("mouseover", function() {
    $("#foft").animate({ opacity: 0 });
    $("#cover1t").animate({ opacity: 1 });
    $("#cover1").animate({ opacity: 0.6 });
  });

  $("#cover1t").on("mouseout", function() {
    $("#cover1").animate({ opacity: 0 });
    $("#foft").animate({ opacity: 1 });
    $("#cover1t").animate({ opacity: 0 });
  });

  $("#searchBtn").on("click", function() {
    document.getElementById("searchBox").submit();
  });

  $("#searchButton").on("click", function() {
    document.getElementById("rubrik").style.marginRight = "5%";
  });

  $("#searchBtn2").on("click", function() {
    document.getElementById("searchBox2").submit();
  });
  $("#searchButton").on("click", function() {
    document.getElementById("searchBtn").style.display = "block";
    document.getElementById("searchButton").style.display = "none";
    $("#searchInput").animate(
      {
        width: "59%",
        opacity: 1
      },
      400,
      "linear",
      function() {
        $(this).focus();
      }
    );
  });
  $("#searchInput").on("focusout", function() {
    setTimeout(function() {
      document.getElementById("searchBtn").style.display = "none";
      document.getElementById("searchButton").style.display = "block";
    }, 100);

    $(this).animate(
      {
        width: "0%",
        opacity: 0
      },
      400
    );

    $("#rubrik").animate(
      {
        marginRight: "64%"
      },
      400
    );
  });
});

var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
  var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar1").style.top = "0px";
    document.getElementById("navbar2").style.top = "76px";
  } else {
    document.getElementById("navbar1").style.top = "-76px";
    document.getElementById("navbar2").style.top = "0px";
  }
  prevScrollpos = currentScrollPos;
};

var inactivityTime = function() {
  var time;
  window.onload = resetTimer;
  document.onmousemove = resetTimer;
  document.onkeypress = resetTimer;

  function logout() {
    location.href = "../logga-in/logga-in.php";
  }

  function resetTimer() {
    clearTimeout(time);
    time = setTimeout(logout, 900000);
  }
};
