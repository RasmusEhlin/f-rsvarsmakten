$(function() {
  $("#searchBtn").on("click", function() {
    document.getElementById("searchBox").submit();
  });

  $("#searchButton").on("click", function() {
    document.getElementById("rubrik").style.marginRight = "5%";
  });

  $("#searchBtn2").on("click", function() {
    document.getElementById("searchBox2").submit();
  });
  $("#searchButton").on("click", function() {
    document.getElementById("searchBtn").style.display = "block";
    document.getElementById("searchButton").style.display = "none";
    $("#searchInput").animate(
      {
        width: "59%",
        opacity: 1
      },
      400,
      "linear",
      function() {
        $(this).focus();
      }
    );
  });
  $("#searchInput").on("focusout", function() {
    setTimeout(function() {
      document.getElementById("searchBtn").style.display = "none";
      document.getElementById("searchButton").style.display = "block";
    }, 100);

    $(this).animate(
      {
        width: "0%",
        opacity: 0
      },
      400
    );

    $("#rubrik").animate(
      {
        marginRight: "64%"
      },
      400
    );
  });
});

var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
  var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar1").style.top = "0px";
    document.getElementById("navbar2").style.top = "76px";
  } else {
    document.getElementById("navbar1").style.top = "-76px";
    document.getElementById("navbar2").style.top = "0px";
  }
  prevScrollpos = currentScrollPos;
};
