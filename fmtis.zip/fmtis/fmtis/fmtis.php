<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Försvarsmakten</title>
    <link rel="icon" type="image/png" href="../img/favicon.ico">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css">
    <link rel="stylesheet" href="fmtis.css" type="text/css" />
    <link rel="stylesheet" href="../fontawesome/css/all.css" />
    <script src="jquery.js"></script>
</head>

<body>
    <div class="navbar1" id="navbar1">
        <a class="loga" href="fmtis.php">
            <img src="../img/FM_Svartv_enkel.png" />
        </a>
        <a class="rubrik1" id="rubrik" href="fmtis.php">FÖRSVARSMAKTEN</a>

        <form class="searchBox" id="searchBox" action="fmtis.php">
            <a class="searchIcon" id="searchButton"><i class="fa fa-search"></i></a>
            <a class="searchIcon" id="searchBtn"><i class="fa fa-search"></i></a>
            <input name="search" id="searchInput" type="text" placeholder="Sök.." autocomplete="off" required="">
        </form>

        <a class="användare"><i class="fas fa-user"></i></a>
    </div>

    <div class="navbar2" id="navbar2">
        <a class="ett rum1" href="">Hem</a>
        <a class="två rum" href="">Fys & Friskvård</a>
        <a class="tre rum" href="">Detta Händer I Veckan</a>
        <a class="fyra rum" href="">Planerade Besök</a>
        <a class="fem rum" href="">Omvärldsbevakning</a>
        <a class="sex rum2" href="">Personal</a>
    </div>

    <?php
    include("db.php");

    if (isset($_GET['search'])) {
        $search = "%" . $_GET['search'] . "%";
        $stmt = $dbh->prepare('SELECT * FROM nyheter WHERE rubrik LIKE :search OR kategori LIKE :search OR text LIKE :search OR fornamn LIKE :search OR efternamn LIKE :search OR enhet LIKE :search');
        $stmt->execute(array('search' => $search));
        $result = $stmt->fetchAll();

        if ($stmt->rowCount() <= 0) {
            echo "<div class='noll'>";
            echo "Din sökning har inte hittas!</div>";
        }

        foreach ($result as $r) {
            ?>
    <div class="setup">
        <div class='se'>
            <a class="rubrik"> <?php echo $r['rubrik']; ?> </a>
            <br>
            <a class="kategori"> <?php echo $r['kategori']; ?> </a>
            <br>
            <br>
            <a class="text"> <?php echo $r['text']; ?> </a>
            <br>
            <br>
            <img class="bild" src="../img/<?php echo $r['bild']; ?>">
            <br>
            <br>
            <a class="fornamn"> <?php echo $r['fornamn']; ?> </a>
            <a class="efternamn"> <?php echo $r['efternamn']; ?> - </a>
            <a class="enhet"> <?php echo $r['enhet']; ?> </a>
            <br>
            <a class="datum"> <?php echo $r['datum']; ?> </a>
        </div>
    </div>
    <?php

}
} else {
    ?>

    <div class="sek">
        <div id="cover1" class="cover1"></div>
        <div id="cover2" class="cover2"></div>
        <div id="cover3" class="cover3"></div>
        <div id="cover4" class="cover4"></div>
        <div id="cover5" class="cover5"></div>

        <div id="cover1t" class="cover1t">Fys & Friskvård</div>
        <div id="cover2t" class="cover2t">Detta Händer I Veckan</div>
        <div id="cover3t" class="cover3t">Planerade Besök</div>
        <div id="cover4t" class="cover4t">Omvärldsbevakning</div>
        <div id="cover5t" class="cover5t">Personal</div>

        <div class="fof">
            <div id="foft" class="foft">Fys & Friskvård</div>
        </div>
        <div class="hiv">
            <div id="hivt" class="hivt">Detta Händer I Veckan</div>
        </div>
        <div class="pb">
            <div id="pbt" class="pbt">Planerade Besök</div>
        </div>
        <div class="world">
            <div id="worldt" class="worldt">Omvärldsbevakning</div>
        </div>
        <div class="pers">
            <div id="perst" class="perst">Personal</div>
        </div>
    </div>

    <?php
    $stmt = $dbh->prepare('SELECT * FROM nyheter ORDER BY datum desc');
    $stmt->execute();
    $result = $stmt->fetchAll();

    if ($stmt->rowCount() <= 0) {
        echo "<div class='noll'>";
        echo "Inga nyheter</div>";
    }

    foreach ($result as $r) {
        ?>
    <div class="setup">
        <div class='se'>
            <a class="rubrik"> <?php echo $r['rubrik']; ?> </a>
            <br>
            <a class="kategori"> <?php echo $r['kategori']; ?> </a>
            <br>
            <br>
            <a class="text"> <?php echo $r['text']; ?> </a>
            <br>
            <br>
            <img class="bild" src="../img/<?php echo $r['bild']; ?>">
            <br>
            <br>
            <a class="fornamn"> <?php echo $r['fornamn']; ?> </a>
            <a class="efternamn"> <?php echo $r['efternamn']; ?> - </a>
            <a class="enhet"> <?php echo $r['enhet']; ?> </a>
            <br>
            <a class="datum"> <?php echo $r['datum']; ?> </a>
        </div>
    </div>

    <?php

}
}
?>

    <script src="main.js"></script>
    <script>
        inactivityTime();
    </script>
</body>

</html> 