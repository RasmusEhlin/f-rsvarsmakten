<?php
session_start();
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>findAccount</title>
</head>

<body>
<?php
	$dbh = new PDO('mysql:host=localhost;dbname=försvarsmakten', 'root', 'password');
	
	$nman = $_POST['namn'];
	$password = $_POST['password'];
	
	$sql = $dbh->prepare("SELECT * FROM användare");
	$sql->execute();
	$result = $sql->fetchAll();
	
	foreach($result as $r){
		if($namn == $r['namn'] && sha1($password) == $r['password']){
			$_SESSION['fn'] = $r['firstName'];
			header('Location: ../Lobit.php');
			exit;
		}
		else{
			header('Location: Sign-in.php?fel');
		}
	}
?>
</body>
</html>