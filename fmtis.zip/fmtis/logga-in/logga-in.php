<?php
session_start();
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Försvarsmakten - Logga In</title>
		<link rel="icon" type="image/png" href="../img/favicon.ico">
		<link rel="stylesheet" type="text/css" media="screen" href="main.css">
		<link rel="stylesheet" href="logga-in.css" type="text/css"/>
		<link
			rel="stylesheet"
			href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
			integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
			crossorigin="anonymous"
		/>
		<link
			rel="stylesheet"
			href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
			integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr"
			crossorigin="anonymous"
		/>
		<script src="main.js"></script>
	</head>

	<body>
		<div class="top">
			<br>
			<img class="loga" src="../img/FM_detalj_RGB.gif"/>

			<div class="box">
				<h2>Försvarsmakten</h2>

				<?php
					if(isset($_GET['fel']))
					{echo'<a class="fail" ><i style="margin-left: 0;" class="fas fa-exclamation-triangle"></i> Fel namn eller lösenord</a>';}
				?>

				<form action="findAccount.php" method="post">
					<div class="inputBox">
						<input type="text" name="email" maxlength="100" autocomplete="off" required="">
						<label>Användnamn</label>
					</div>
		
					<div class="inputBox">
						<input type="password" name="password" maxlength="50" autocomplete="off" required="">
						<label>Lösenord</label>
					</div>
		
					<input type="submit" name="submit" value="Logga In">
				</form>
			</div>
		</div>
	</body>
</html>