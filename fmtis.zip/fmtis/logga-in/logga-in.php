<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Försvarsmakten - Logga In</title>
    <link rel="icon" type="image/png" href="../img/favicon.ico">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css">
    <link rel="stylesheet" href="logga-in.css" type="text/css" />
    <link rel="stylesheet" href="../fontawesome/css/all.css" />
    <script src="main.js"></script>
</head>

<body>
    <div class="top">
        <br>
        <img class="loga" src="../img/FM_detalj_RGB.gif">

        <div class="box">
            <h2>Försvarsmakten</h2>

            <?php
            if (isset($_GET['fel'])) {
                echo '<a class="fail" ><i style="margin-left: 0;" class="fas fa-exclamation-circle"></i> Fel Användarnamn eller Lösenord</a>';
            }
            ?>

            <form action="findAccount.php" method="post">
                <div class="inputBox an">
                    <input type="text" name="username" maxlength="50" autocomplete="off" required="">
                    <label>Användarnamn</label>
                </div>

                <div class="inputBox">
                    <input type="password" name="password" maxlength="50" autocomplete="off" required="">
                    <label>Lösenord</label>
                </div>

                <input type="submit" name="submit" value="Logga In">
            </form>
        </div>
    </div>
</body>

</html> 