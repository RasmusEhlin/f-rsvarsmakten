<?php

class Database
{
    private $db = null;

    function __construct()
    {
        $this->db = new mysqli("localhost", "root", null, "fmtis");

        if ($this->db->connect_error) {
            die("DB Connection Error");
        }
    }

    public function close()
    {
        $this->db->close();
    }

    private function executePrepared($query, $types, ...$values)
    {
        // Prepare statement
        $cmnd = $this->db->prepare($query);
        $cmnd->bind_param($types, ...$values);
        $cmnd->execute();

        // Return depending on if value was returned or not
        $result = $cmnd->get_result();
        return $result ? $result->fetch_all() : $this->db->error;
    }

    private function login($username, $password)
    {
        // Hash password
        $hashed = hash("sha3-256", $password);

        // login
        $result = $this->executePrepared("SELECT COUNT(*) FROM användare WHERE anvandarnamn=? AND losenord=?", "ss", $username, $hashed);

        // Check login
        if ($result[0][0] <= 0) {
            return false;
        }

        // Set session and return true
        $_SESSION['anvandare'] = $username;
        return true;
    }
}
 