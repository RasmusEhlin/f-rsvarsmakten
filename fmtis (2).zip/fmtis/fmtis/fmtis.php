<?php
session_start();
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Försvarsmakten</title>
    <link rel="icon" type="image/png" href="../img/favicon.ico">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css">
    <link rel="stylesheet" href="fmtis.css" type="text/css" />
    <link rel="stylesheet" href="../fontawesome/css/all.css" />
    <script src="jquery.js"></script>
</head>

<body>
    <div class="navbar1" id="navbar1">
        <a class="loga" href="fmtis.php">
            <img src="../img/FM_Svartv_enkel.png" />
        </a>
        <a class="rubrik" id="rubrik" href="fmtis.php">FÖRSVARSMAKTEN</a>

        <form class="searchBox" id="searchBox" action="fmtis.php">
            <a class="searchIcon" id="searchButton"><i class="fa fa-search"></i></a>
            <a class="searchIcon" id="searchBtn"><i class="fa fa-search"></i></a>
            <input name="search" id="searchInput" type="text" placeholder="Sök.." autocomplete="off" required="">
        </form>

        <a class="användare"><i class="fas fa-user"></i></a>
    </div>

    <div class="navbar2" id="navbar2">
        <a class="ett rum1" href="">Hem</a>
        <a class="två rum" href="">Fys & Friskvård</a>
        <a class="tre rum" href="">Detta Händer I Veckan</a>
        <a class="fyra rum" href="">Planerade Besök</a>
        <a class="fem rum" href="">Omvärldsbevakning</a>
        <a class="sex rum2" href="">Personal</a>
    </div>

    <div class="top"></div>

    <script src="main.js"></script>
</body>

</html> 