$(function() {
  $("#fys").on("click", function() {
    $("#fys").animate(
      {
        height: "100px"
      },
      100
    );

    $("#fys").animate(
      {
        height: ""
      },
      100
    );

    document.getElementById("detta").style.height = "";
    document.getElementById("plan").style.height = "";
    document.getElementById("veck").style.height = "";
  });

  $("#detta").on("click", function() {
    $("#detta").animate(
      {
        height: "100px"
      },
      100
    );

    document.getElementById("fys").style.height = "";
    document.getElementById("plan").style.height = "";
    document.getElementById("veck").style.height = "";
  });

  $("#plan").on("click", function() {
    $("#plan").animate(
      {
        height: "100px"
      },
      100
    );

    document.getElementById("fys").style.height = "";
    document.getElementById("detta").style.height = "";
    document.getElementById("veck").style.height = "";
  });

  $("#veck").on("click", function() {
    $("#veck").animate(
      {
        height: "100px"
      },
      100
    );

    document.getElementById("fys").style.height = "";
    document.getElementById("detta").style.height = "";
    document.getElementById("plan").style.height = "";
  });

  $("#användare").on("mouseover", function() {
    document.getElementById("userContent").style.display = "block";
    document.getElementById("userContent").style.opacity = "1";
  });

  $("#användare").on("mouseout", function() {
    document.getElementById("userContent").style.display = "none";
    document.getElementById("userContent").style.opacity = "0";
  });

  $("#userContent").on("mouseover", function() {
    document.getElementById("userContent").style.display = "block";
    document.getElementById("userContent").style.opacity = "1";
  });

  $("#userContent").on("mouseout", function() {
    document.getElementById("userContent").style.display = "none";
    document.getElementById("userContent").style.opacity = "0";
  });

  $("#användare").on("mouseover", function() {
    document.getElementById("användare").style.color = "#4286f4";
  });

  $("#användare").on("mouseout", function() {
    document.getElementById("användare").style.color = "black";
  });

  $("#userContent").on("mouseover", function() {
    document.getElementById("användare").style.color = "#4286f4";
  });

  $("#userContent").on("mouseout", function() {
    document.getElementById("användare").style.color = "black";
  });

  $("#cover1").on("mouseover", function() {
    document.getElementById("cover1").style.opacity = "0.6";
    document.getElementById("cover1t").style.opacity = "1";
    document.getElementById("foft").style.opacity = "0";
  });

  $("#cover1").on("mouseout", function() {
    document.getElementById("cover1").style.opacity = "0";
    document.getElementById("cover1t").style.opacity = "0";
    document.getElementById("foft").style.opacity = "1";
  });

  $("#cover1t").on("mouseover", function() {
    document.getElementById("cover1").style.opacity = "0.6";
    document.getElementById("cover1t").style.opacity = "1";
    document.getElementById("foft").style.opacity = "0";
  });

  $("#cover1t").on("mouseout", function() {
    document.getElementById("cover1").style.opacity = "0";
    document.getElementById("cover1t").style.opacity = "0";
    document.getElementById("foft").style.opacity = "1";
  });

  $("#cover2").on("mouseover", function() {
    document.getElementById("cover2").style.opacity = "0.6";
    document.getElementById("cover2t").style.opacity = "1";
    document.getElementById("hivt").style.opacity = "0";
  });

  $("#cover2").on("mouseout", function() {
    document.getElementById("cover2").style.opacity = "0";
    document.getElementById("cover2t").style.opacity = "0";
    document.getElementById("hivt").style.opacity = "1";
  });

  $("#cover2t").on("mouseover", function() {
    document.getElementById("cover2").style.opacity = "0.6";
    document.getElementById("cover2t").style.opacity = "1";
    document.getElementById("hivt").style.opacity = "0";
  });

  $("#cover2t").on("mouseout", function() {
    document.getElementById("cover2").style.opacity = "0";
    document.getElementById("cover2t").style.opacity = "0";
    document.getElementById("hivt").style.opacity = "1";
  });

  $("#cover3").on("mouseover", function() {
    document.getElementById("cover3").style.opacity = "0.6";
    document.getElementById("cover3t").style.opacity = "1";
    document.getElementById("pbt").style.opacity = "0";
  });

  $("#cover3").on("mouseout", function() {
    document.getElementById("cover3").style.opacity = "0";
    document.getElementById("cover3t").style.opacity = "0";
    document.getElementById("pbt").style.opacity = "1";
  });

  $("#cover3t").on("mouseover", function() {
    document.getElementById("cover3").style.opacity = "0.6";
    document.getElementById("cover3t").style.opacity = "1";
    document.getElementById("pbt").style.opacity = "0";
  });

  $("#cover3t").on("mouseout", function() {
    document.getElementById("cover3").style.opacity = "0";
    document.getElementById("cover3t").style.opacity = "0";
    document.getElementById("pbt").style.opacity = "1";
  });

  $("#cover4").on("mouseover", function() {
    document.getElementById("cover4").style.opacity = "0.6";
    document.getElementById("cover4t").style.opacity = "1";
    document.getElementById("worldt").style.opacity = "0";
  });

  $("#cover4").on("mouseout", function() {
    document.getElementById("cover4").style.opacity = "0";
    document.getElementById("cover4t").style.opacity = "0";
    document.getElementById("worldt").style.opacity = "1";
  });

  $("#cover4t").on("mouseover", function() {
    document.getElementById("cover4").style.opacity = "0.6";
    document.getElementById("cover4t").style.opacity = "1";
    document.getElementById("worldt").style.opacity = "0";
  });

  $("#cover4t").on("mouseout", function() {
    document.getElementById("cover4").style.opacity = "0";
    document.getElementById("cover4t").style.opacity = "0";
    document.getElementById("worldt").style.opacity = "1";
  });

  $("#cover5").on("mouseover", function() {
    document.getElementById("cover5").style.opacity = "0.6";
    document.getElementById("cover5t").style.opacity = "1";
    document.getElementById("perst").style.opacity = "0";
  });

  $("#cover5").on("mouseout", function() {
    document.getElementById("cover5").style.opacity = "0";
    document.getElementById("cover5t").style.opacity = "0";
    document.getElementById("perst").style.opacity = "1";
  });

  $("#cover5t").on("mouseover", function() {
    document.getElementById("cover5").style.opacity = "0.6";
    document.getElementById("cover5t").style.opacity = "1";
    document.getElementById("perst").style.opacity = "0";
  });

  $("#cover5t").on("mouseout", function() {
    document.getElementById("cover5").style.opacity = "0";
    document.getElementById("cover5t").style.opacity = "0";
    document.getElementById("perst").style.opacity = "1";
  });

  $("#searchBtn").on("click", function() {
    document.getElementById("searchBox").submit();
  });

  $("#searchButton").on("click", function() {
    document.getElementById("rubrik").style.marginRight = "5%";
  });

  $("#searchBtn2").on("click", function() {
    document.getElementById("searchBox2").submit();
  });
  $("#searchButton").on("click", function() {
    document.getElementById("searchBtn").style.display = "block";
    document.getElementById("searchButton").style.display = "none";
    $("#searchInput").animate(
      {
        width: "59%",
        opacity: 1
      },
      400,
      "linear",
      function() {
        $(this).focus();
      }
    );
  });
  $("#searchInput").on("focusout", function() {
    setTimeout(function() {
      document.getElementById("searchBtn").style.display = "none";
      document.getElementById("searchButton").style.display = "block";
    }, 100);

    $(this).animate(
      {
        width: "0%",
        opacity: 0
      },
      400
    );

    $("#rubrik").animate(
      {
        marginRight: "64%"
      },
      400
    );
  });
});

var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
  var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar1").style.top = "0px";
    document.getElementById("navbar2").style.top = "76px";
  } else {
    document.getElementById("navbar1").style.top = "-76px";
    document.getElementById("navbar2").style.top = "0px";
  }
  prevScrollpos = currentScrollPos;
};

var inactivityTime = function() {
  var time;
  window.onload = resetTimer;
  document.onmousemove = resetTimer;
  document.onkeypress = resetTimer;

  function logout() {
    location.href = "../logga-in/logga-ut.php";
  }

  function resetTimer() {
    clearTimeout(time);
    time = setTimeout(logout, 900000);
  }
};
