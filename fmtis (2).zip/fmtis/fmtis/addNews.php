    <?php
    include("db.php");

    $rubrik = $_POST['rubrik'];
    $kategori = $_POST['kategori'];
    $text = $_POST['text'];
    $bild = $_POST['bild'];
    $fornamn = $_POST['fornamn'];
    $efternamn = $_POST['efternamn'];
    $enhet = $_POST['enhet'];
    $datum = $_POST['datum'];

    $sql = $dbh->prepare("INSERT INTO nyheter VALUES ('$rubrik','$kategori','$text','$bild','$fornamn','$efternamn','$enhet',CURRENT_TIMESTAMP)");
    $sql->execute();
    header('Location: fmtis.php');

    ?> 